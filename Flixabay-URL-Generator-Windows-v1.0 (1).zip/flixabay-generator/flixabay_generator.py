import csv
import secrets
import string
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from urllib.parse import urlsplit

ALPHABET = string.ascii_letters + string.digits

class Generator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Flixabay URL Generator')
        self.geometry('780x600')
        self.urls = []
        self.base = tk.StringVar(value='https://flixabay.com/play/')
        self.count = tk.IntVar(value=100)
        self.length = tk.IntVar(value=8)
        self.unique = set()
        form = ttk.Frame(self, padding=16)
        form.pack(fill='x')
        for label, var in [('Base URL', self.base), ('Jumlah URL', self.count), ('Panjang kode', self.length)]:
            row = ttk.Frame(form)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text=label, width=17).pack(side='left')
            ttk.Entry(row, textvariable=var).pack(side='left', fill='x', expand=True)
        actions = ttk.Frame(self, padding=(16, 4))
        actions.pack(fill='x')
        ttk.Button(actions, text='Generate', command=self.generate).pack(side='left', padx=3)
        ttk.Button(actions, text='Copy All', command=self.copy).pack(side='left', padx=3)
        ttk.Button(actions, text='Export TXT', command=self.export_txt).pack(side='left', padx=3)
        ttk.Button(actions, text='Export CSV', command=self.export_csv).pack(side='left', padx=3)
        ttk.Button(actions, text='Clear', command=self.clear).pack(side='left', padx=3)
        self.status = ttk.Label(self, text='Siap', padding=(16, 5))
        self.status.pack(anchor='w')
        frame = ttk.Frame(self, padding=(16, 0, 16, 16))
        frame.pack(fill='both', expand=True)
        self.output = tk.Text(frame, wrap='none')
        scroll = ttk.Scrollbar(frame, command=self.output.yview)
        self.output.configure(yscrollcommand=scroll.set)
        self.output.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')

    def generate(self):
        try:
            base = self.base.get().strip()
            parsed = urlsplit(base)
            if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise ValueError('Base URL harus HTTPS valid tanpa query/fragment.')
            count, length = self.count.get(), self.length.get()
            if not 1 <= count <= 10000 or not 8 <= length <= 24:
                raise ValueError('Jumlah 1–10.000 dan panjang kode 8–24.')
            base = base.rstrip('/') + '/'
            generated = []
            while len(generated) < count:
                url = base + ''.join(secrets.choice(ALPHABET) for _ in range(length))
                if url not in self.unique:
                    self.unique.add(url)
                    generated.append(url)
            self.urls.extend(generated)
            self.output.insert('end', '\n'.join(generated) + '\n')
            self.status.config(text=f'{len(generated)} URL baru · total {len(self.urls)}')
        except (ValueError, tk.TclError) as exc:
            messagebox.showerror('Input tidak valid', str(exc))

    def copy(self):
        self.clipboard_clear()
        self.clipboard_append('\n'.join(self.urls))
        self.status.config(text=f'{len(self.urls)} URL disalin')

    def export_txt(self):
        path = filedialog.asksaveasfilename(defaultextension='.txt', filetypes=[('Text', '*.txt')])
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self.urls) + '\n')

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')])
        if path:
            with open(path, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['url'])
                writer.writerows((u,) for u in self.urls)

    def clear(self):
        self.urls.clear()
        self.unique.clear()
        self.output.delete('1.0', 'end')
        self.status.config(text='Dibersihkan')

if __name__ == '__main__':
    Generator().mainloop()
