@echo off
cd /d "%~dp0"
py -3 flixabay_generator.py
if errorlevel 1 pause
