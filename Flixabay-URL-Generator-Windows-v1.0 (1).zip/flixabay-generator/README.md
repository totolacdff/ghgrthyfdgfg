# Flixabay URL Generator

Aplikasi Windows sederhana untuk membuat daftar URL unik dengan prefix HTTPS yang dapat diganti. Default `https://flixabay.com/play/`.

## Jalankan
Instal Python 3.11+, ekstrak ZIP, dan klik `START-WINDOWS.bat`. Tidak membutuhkan dependensi tambahan untuk menjalankan GUI.

## Buat EXE
Klik `BUILD-EXE-WINDOWS.bat` pada Windows dengan Python dan koneksi untuk instalasi PyInstaller. Hasilnya ada di `dist/FlixabayGenerator.exe`.

## Fitur
- Base URL custom
- 1–10.000 URL per generate
- Panjang kode 8–24 karakter alfanumerik
- Generator kriptografis dan deduplikasi selama aplikasi berjalan
- Copy all, ekspor TXT/CSV, clear

Generator hanya menghasilkan string URL; halaman yang dituju tidak otomatis dibuat di server. Gunakan hanya untuk URL yang Anda kelola dan penggunaan yang sah, bukan untuk menghindari deteksi spam.
